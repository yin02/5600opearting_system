#ifndef MPG2KM_H//"if not defined.
#define MPG2KM_H

float mpg2kml(float mpg);
float mpg2lphm(float mpg);
float lph2mpg(float lph);

#endif
