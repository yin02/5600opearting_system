// readfile.h
#ifndef READFILE_H
#define READFILE_H

#include "queue.h"

// Declare the function here
void readFileAndEnqueue(const char *filename, Queue *queue);

#endif
