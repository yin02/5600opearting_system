#include <stdio.h>
#include <ctype.h>
#include <string.h>

// Define the Polybius square (5x5 grid)
char polybiusSquare[5][5] = {
    {'A', 'B', 'C', 'D', 'E'},
    {'F', 'G', 'H', 'I', 'K'}, // I and J combined
    {'L', 'M', 'N', 'O', 'P'},
    {'Q', 'R', 'S', 'T', 'U'},
    {'V', 'W', 'X', 'Y', 'Z'}
};

// Function to encode the plaintext using Polybius cipher
void pbEncode(const char *plaintext, char *encoded) {
    int k = 0;
    for (int i = 0; plaintext[i] != '\0'; i++) {
        char letter = toupper(plaintext[i]);
        if (letter == 'J') letter = 'I';  // Combine I and J

        // Find the letter in the Polybius square
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                if (polybiusSquare[row][col] == letter) {
                    encoded[k++] = '1' + row; // Row number
                    encoded[k++] = '1' + col; // Column number
                    break;
                }
            }
        }
    }
    encoded[k] = '\0'; // Null-terminate the encoded string
}

// Function to decode the ciphertext using Polybius cipher
void pbDecode(const char *ciphertext, char *decoded) {
    int k = 0;
    for (int i = 0; ciphertext[i] != '\0'; i += 2) {
        int row = ciphertext[i] - '1';
        int col = ciphertext[i + 1] - '1';
        decoded[k++] = polybiusSquare[row][col];
    }
    decoded[k] = '\0'; // Null-terminate the decoded string
}
