#ifndef POLYBIUS_H
#define POLYBIUS_H

void pbEncode(const char *plaintext, char *encoded);
void pbDecode(const char *ciphertext, char *decoded);

#endif
