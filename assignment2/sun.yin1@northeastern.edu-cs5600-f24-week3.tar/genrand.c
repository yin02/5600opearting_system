#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Linear Congruential Generator (LCG) parameters
#define MULTIPLIER 1103515245
#define INCREMENT 12345
#define MODULUS 2147483648 // 2^31

unsigned int seed = 123456789; // initial seed, you can change or set via a function

// Function to generate a random number using LCG
int genRand(int min, int max) {
    seed = (MULTIPLIER * seed + INCREMENT) % MODULUS;
    return min + (seed % (max - min + 1));
}

int main(int argc, char *argv[]) {
    if (argc < 3 || argc > 4) {
        printf("Usage: %s <number_of_randoms> <file_name> [-a]\n", argv[0]);
        return 1;
    }

    int numRandoms = atoi(argv[1]);
    char *fileName = argv[2];
    int appendMode = (argc == 4 && strcmp(argv[3], "-a") == 0);

    FILE *file;
    if (appendMode) {
        file = fopen(fileName, "a"); // Open in append mode
    } else {
        file = fopen(fileName, "w"); // Open in write (overwrite) mode
    }

    if (file == NULL) {
        printf("Error: Could not open file %s\n", fileName);
        return 1;
    }

    // Generate random numbers and write to file
    for (int i = 0; i < numRandoms; i++) {
        int randNum = genRand(1, 100); // Generate random number in range [1, 100]
        fprintf(file, "%d\n", randNum);
    }

    fclose(file);
    printf("Generated %d random numbers and wrote to %s\n", numRandoms, fileName);
    return 0;
}
