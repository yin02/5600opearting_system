#include <stdio.h>
#include <string.h>
#include "polybius.h"  // Include the header file for the cipher functions

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s -e/-d <text>\n", argv[0]);
        return 1;
    }

    char output[256];  // Buffer to store the encoded/decoded result

    if (strcmp(argv[1], "-e") == 0) {
        pbEncode(argv[2], output);  // Call the encoding function
        printf("Encoded: %s\n", output);
    } else if (strcmp(argv[1], "-d") == 0) {
        pbDecode(argv[2], output);  // Call the decoding function
        printf("Decoded: %s\n", output);
    } else {
        printf("Invalid option. Use -e to encode or -d to decode.\n");
    }

    return 0;
}
